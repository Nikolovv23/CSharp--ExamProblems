﻿// Create UnitTests for RailwayStation class

namespace Railway
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            
        }
    }
}