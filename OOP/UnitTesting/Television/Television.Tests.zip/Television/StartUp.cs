﻿//Create UnitTests for TelevisionDevice class

namespace Television
{
    public class StartUp
    {
        static void Main(string[] args)
        {

        }
    }
}
